Hi, I hope you are doing well!

This repo contains the code for Solana Landing Page Design. Its made using pure HTML, CSS and Javascript. 
Let me know if you like my work. 
Thanks
